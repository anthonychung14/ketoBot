define(function (require) {
  return require('ui/registry/_registry')({
    name: 'chromeNavControls',
    order: ['order']
  });
});
